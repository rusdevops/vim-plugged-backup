Test
====
.. note:: For testing github rendering
 
* list 1
* list 2

:Sections:  Section level and section number auto detected.


:Lists:    Auto Numbered and auto leveled bullet and enumerated list.
:Blocks:   Highlighting and folding blocks.
:Links:    Jumping with links.
:Table:    Auto formatted table.
:Folding:  Fold document by document structures (Section/List/Block).
:Indent:   Improved indentation 
:Insert:   Improvment of some mapping in insert mode.
:Highlighting: Improved syntax file. 
:Publish:  some wrapper to convert rst files to html/xml/latex/odt/... 
            (require python docutils package )
