""" Implementing a document parser for folding.


1. Think things first.
    
    When we are using rst. 
    
    Partly because it's more concise.
    Partly because it's more complex.

    

    We add fold, for overviewing it more easily.


    We add indent/autoindent, for writing it more easily.


    We add xxx xxx , for using it more widely


2. Think about fold.

    With statemachine

"""

import re
