#!/bin/bash

mkdir -p ~/.vim
cp -r after ~/.vim
cp -r autoload ~/.vim
cp -r ftplugin ~/.vim
cp -r indent ~/.vim
cp -r plugin ~/.vim
cp -r syntax ~/.vim

