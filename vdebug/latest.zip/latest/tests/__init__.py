import sys

sys.path.append('tests')
sys.path.append('python3')
