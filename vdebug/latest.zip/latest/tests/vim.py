"""A dummy file as the real vim module can only be loaded from within vim."""
