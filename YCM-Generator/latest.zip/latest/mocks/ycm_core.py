# This file defines a mock of the ycm_core module so we can test template.py by
# running it.

def CompilationDatabase(x):
    pass

