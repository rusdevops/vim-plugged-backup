selECT * FROM foo WHERE id IN (SELECT id FROM bar);
