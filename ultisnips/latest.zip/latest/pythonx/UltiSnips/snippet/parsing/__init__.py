"""Code related to turning text into snippets."""
